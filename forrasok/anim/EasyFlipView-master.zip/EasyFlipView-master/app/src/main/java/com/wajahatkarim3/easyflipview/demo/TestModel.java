package com.wajahatkarim3.easyflipview.demo;

class TestModel {
  boolean isFlipped;
}
